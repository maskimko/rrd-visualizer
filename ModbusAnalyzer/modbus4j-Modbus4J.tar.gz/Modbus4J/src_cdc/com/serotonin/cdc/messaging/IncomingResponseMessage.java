package com.serotonin.cdc.messaging;

public interface IncomingResponseMessage extends IncomingMessage {
    // A marker interface
}
