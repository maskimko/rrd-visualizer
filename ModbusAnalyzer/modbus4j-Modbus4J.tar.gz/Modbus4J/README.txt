modbus4J.jar requires seroUtils.jar to be on the classpath.

A discussion forum for this package can be found at http://mango.serotoninsoftware.com/forum/forums/show/11.page. 